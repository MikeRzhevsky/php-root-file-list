<?php
/*
@MikeRzhevsky miker.ru@gmail.com
 */
return [
    db=>
    ['host' => 'localhost',
    'dbname' =>'Tutorial',
    'user' => 'user',
    'password' => '']
];