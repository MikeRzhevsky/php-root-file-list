<?php

return [
    db=>
    ['host' => 'localhost',
    'dbname' =>'Tutorial',
    'user' => 'user',
    'password' => '']
];