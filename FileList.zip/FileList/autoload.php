<?php

function __autoload($class)
{
    require  dirname(__FILE__) . '/' . str_replace('\\','/',$class) . '.php';

}
